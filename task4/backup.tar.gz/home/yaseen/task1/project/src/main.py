def add(a: int, b: int) -> int:
    
    return a + b


if __name__ == "__main__":
    x, y = 5, 7
    print(f"The sum of {x} and {y} is {add(x, y)}")

